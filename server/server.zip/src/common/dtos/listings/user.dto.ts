import { IsString, IsNotEmpty, IsEmail, Matches } from "class-validator";

export class UserDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsEmail({}, { message: "Please enter a valid email address" })
  @IsString()
  @IsNotEmpty()
  email: string;

  @Matches(/^((\+20|0020)?1[0-9]{9})$/, {
    message: "Please enter a valid egyptian phone number starting with +20",
  })
  @IsString()
  @IsNotEmpty()
  phoneNumber: string;
}
