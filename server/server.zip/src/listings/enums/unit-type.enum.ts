export enum UnitType {
  "APARTMENT" = "Apartment",
  "VILLA" = "Villa",
  "DUPLEX" = "Duplex",
}
